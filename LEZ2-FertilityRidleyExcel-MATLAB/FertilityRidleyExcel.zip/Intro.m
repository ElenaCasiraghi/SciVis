function res = Intro(dimy, dimx)
    disp('Hello World!!');
   
    x = zeros(dimy, dimx);

    figure(); imshow(x)

end